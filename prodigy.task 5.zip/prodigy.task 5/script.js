const apiKey = 'YOUR_API_KEY'; 
document.addEventListener('DOMContentLoaded', (event) => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const { latitude, longitude } = position.coords;
            fetchWeatherByCoords(latitude, longitude);
        });
    }
});
function fetchWeather() {
    const location = document.getElementById('location-input').value;
    if (location) {
        fetchWeatherByLocation(location);
    } else {
        alert('Please enter a location');
    }
}
function fetchWeatherByLocation(location) {
    const url = https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}&units=metric;
    fetchWeatherData(url);
}
function fetchWeatherByCoords(latitude, longitude) {
    const url = https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=metric;
    fetchWeatherData(url);
}
function fetchWeatherData(url) {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                displayWeather(data);
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            alert('Error fetching weather data');
            console.error(error);
        });
}
function displayWeather(data) {
    const weatherDiv = document.getElementById('weather');
    weatherDiv.innerHTML = `
        <h2>Weather in ${data.name}</h2>
        <p>${data.weather[0].description}</p>
        <p>Temperature: ${data.main.temp}°C</p>
        <p>Humidity: ${data.main.humidity}%</p>
        <p>Wind Speed: ${data.wind.speed} m/s</p>
    `;
}