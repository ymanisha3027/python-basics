let startTime;
let running = false;
let lapCounter = 1;
let laps = [];

function startStop() {
  if (running) {
    clearInterval(interval);
    running = false;
    document.querySelector('button:nth-of-type(1)').innerHTML = 'Resume';
  } else {
    startTime = Date.now() - (laps.length > 0 ? laps.reduce((acc, lap) => acc + lap, 0) : 0);
    interval = setInterval(updateDisplay, 10);
    running = true;
    document.querySelector('button:nth-of-type(1)').innerHTML = 'Pause';
  }
}

function pause() {
  clearInterval(interval);
  running = false;
  document.querySelector('button:nth-of-type(1)').innerHTML = 'Resume';
}

function reset() {
  clearInterval(interval);
  running = false;
  document.querySelector('button:nth-of-type(1)').innerHTML = 'Start';
  document.getElementById('display').innerHTML = '00:00:00.000';
  laps = [];
  lapCounter = 1;
  document.getElementById('laps').innerHTML = '';
}

function lap() {
  if (running) {
    let currentTime = Date.now();
    let lapTime = currentTime - startTime - laps.reduce((acc, lap) => acc + lap, 0);
    laps.push(lapTime);
    let formattedTime = formatTime(lapTime);
    let lapItem = document.createElement('li');
    lapItem.innerHTML = `Lap ${lapCounter}: ${formattedTime}`;
    lapCounter++;
    document.getElementById('laps').appendChild(lapItem);
  }
}

function updateDisplay() {
  let elapsedTime = Date.now() - startTime - laps.reduce((acc, lap) => acc + lap, 0);
  let formattedTime = formatTime(elapsedTime);
  document.getElementById('display').innerHTML = formattedTime;
}

function formatTime(milliseconds) {
  let hours = Math.floor(milliseconds / (1000 * 60 * 60));
  let minutes = Math.floor((milliseconds % (1000 * 60 * 60)) / (1000 * 60));
  let seconds = Math.floor((milliseconds % (1000 * 60)) / 1000);
  let ms = milliseconds % 1000;
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}.${pad(ms, 3)}`;
}

function pad(number, length = 2) {
  return ('0' + number).slice(-length);
}
